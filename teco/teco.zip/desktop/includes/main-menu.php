<div class="header-bot">
    <nav>
    <div class="slider slider-menu">
        <div class="item-menu"><a href="index.php" class="selected">Terbaru</a></div>
            <div class="item-menu"><a href="terpopuler.php">Terpopuler</a></div>
            <div class="item-menu"><a href="favorit.php">Berita Favorit</a></div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>News</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php" class="selected">Nasional</a></div>
                    <div class="item-submenu"><a href="kanal.php">Metro</a></div>
                    <div class="item-submenu"><a href="kanal.php">Bisnis</a></div>
                    <div class="item-submenu"><a href="kanal.php">Dunia</a></div>
                    <div class="item-submenu"><a href="kanal.php">Fokus</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Multimedia</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal-video.php">Video</a></div>
                    <div class="item-submenu"><a href="kanal-foto.php">Foto</a></div>
                    <div class="item-submenu"><a href="kanal-podcast.php">Podcast</a></div>
                </div>
            </div>
            <div class="item-menu"><a href="kanal.php">Seleb</a></div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Gaya Hidup</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Gaya</a></div>
                    <div class="item-submenu"><a href="kanal.php">Cantik</a></div>
                    <div class="item-submenu"><a href="kanal.php">Travel</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Olahraga</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Bola</a></div>
                    <div class="item-submenu"><a href="kanal.php">Sport</a></div>
                </div>
            </div>
            <div class="item-menu"><a href="kanal.php">Otomotif</a></div>
            <div class="item-menu"><a href="kanal.php">Tekno</a></div>
            <div class="item-menu"><a href="kanal.php">Lab Kreatif</a></div>
            <div class="item-menu"><a href="kanal.php">Cek Fakta</a></div>
            <div class="item-menu"><a href="kanal.php">Difabel</a></div>
            <div class="item-menu"><a href="kanal.php">Kolom</a></div>
            <div class="item-menu"><a href="kanal.php">Newsletter</a></div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Nusantara</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Jawa Barat</a></div>
                    <div class="item-submenu"><a href="kanal.php">Bangka Belitung</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Info Tempo</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Inforial</a></div>
                    <div class="item-submenu"><a href="kanal.php">Event</a></div>
                </div>
            </div>      
            <div class="item-menu"><a href="indeks.php">Indeks</a></div>
        </div>
    </nav>
</div>