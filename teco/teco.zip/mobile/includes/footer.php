<footer class="footer">
	<div class="container">
    	<div class="container-col">
            <div class="col12 centerbox">
                <a href="#" class="link margin-bottom-xs">TEMPO.CO</a>
                <a href="#" class="link margin-bottom-xs">Koran Tempo</a>
                <a href="#" class="link margin-bottom-xs">Majalah Tempo</a>
                <a href="#" class="link margin-bottom-xs">Tempo English Magazine</a>
                <a href="#" class="link margin-bottom-xs">TEMPO.CO English</a>
                <a href="#" class="link margin-bottom-xs">Tempo Store</a>
                <a href="#" class="link margin-bottom-xs">Tempo Institute</a>
                <a href="#" class="link">Indonesiana</a>
            </div>
            <div class="col12 centerbox margin-top-sm">
            	<h3 class="title margin-bottom-sm">Ikuti Sosial Media Kami</h3>
                <ul class="sosmed margin-bottom-lg">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><span style="font-size:9px;">LINE</span></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                </ul>
                <h3 class="title  margin-top-sm margin-bottom-sm">Download Aplikasi Tempo</h3>
                <ul class="apps">
                	<li><a href="#"><img src="images/appstore.png"></a></li>
                    <li><a href="#"><img src="images/playstore.png"></a></li>
                </ul>
            </div>
        	<div class="col12 centerbox margin-top-sm">
                <a href="#" class="link tentang margin-bottom-xs">Tentang Kami</a>
                <a href="#" class="link tentang margin-bottom-xs">Pedoman Media Siber</a>
                <a href="#" class="link tentang margin-bottom-xs">Beriklan</a>
                <a href="#" class="link tentang margin-bottom-xs">Ketentuan Layanan</a>
                <a href="#" class="link tentang">Karir</a>
            </div>
            <p class="copy">&copy 2021 TEMPO - Hak Cipta Dilindungi Hukum</p>
        </div>
    </div>
</footer>