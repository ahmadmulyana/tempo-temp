<div class="header-bot">
    <nav>
    <div class="slider slider-menu">
        <div class="item-menu"><a href="index.php" class="selected">Terbaru</a></div>
            <div class="item-menu"><a href="terpopuler.php">Terpopuler</a></div>
            <div class="item-menu"><a href="favorit.php">Berita Favorit</a></div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>News</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php" class="selected">Nasional</a></div>
                    <div class="item-submenu"><a href="kanal.php">Metro</a></div>
                    <div class="item-submenu"><a href="kanal.php">Bisnis</a></div>
                    <div class="item-submenu"><a href="kanal.php">Dunia</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Multimedia</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal-video.php">Video</a></div>
                    <div class="item-submenu"><a href="kanal-foto.php">Foto</a></div>
                    <div class="item-submenu"><a href="kanal-podcast.php">Podcast</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Olahraga</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Bola</a></div>
                    <div class="item-submenu"><a href="kanal.php">Raket</a></div>
                    <div class="item-submenu"><a href="kanal.php">Basket</a></div>
                    <div class="item-submenu"><a href="kanal.php">MotoGP</a></div>
                    <div class="item-submenu"><a href="kanal.php">Formula 1</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Nusantara</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Bandung</a></div>
                    <div class="item-submenu"><a href="kanal.php">Yogyakarta</a></div>
                    <div class="item-submenu"><a href="kanal.php">Surabaya</a></div>
                    <div class="item-submenu"><a href="kanal.php">Makassar</a></div>
                    <div class="item-submenu"><a href="kanal.php">Bali</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Otomotif</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="https://gooto.com" target="_blank">Gooto.com</a></div>
                    <div class="item-submenu"><a href="kanal.php">Motor</a></div>
                    <div class="item-submenu"><a href="kanal.php">Mobile</a></div>
                </div>
            </div>
            <div class="item-menu wsub"><a class="click-sub"><div class="icon-menu"><i class="fa fa-angle-down deicons"></i></div>Gaya Hidup</a>
                <div class="subbox">
                    <div class="item-submenu"><a href="kanal.php">Gaya</a></div>
                    <div class="item-submenu"><a href="kanal.php">Travel</a></div>
                    <div class="item-submenu"><a href="kanal.php">Seleb</a></div>
                </div>
            </div>
            <div class="item-menu"><a href="kanal.php">Teknologi</a></div>
            <div class="item-menu"><a href="https://cantika.com" target="_blank">Cantik</a></div>
            <div class="item-menu"><a href="kanal.php">Cek Fakta</a></div>
            <div class="item-menu"><a href="kanal.php">Inforial</a></div>
            <div class="item-menu"><a href="kanal.php">Difabel</a></div>
            <div class="item-menu"><a href="kanal.php">Grafis</a></div>
            <div class="item-menu"><a href="kanal.php">Data</a></div>
            <div class="item-menu"><a href="kanal.php">Creative Lab</a></div>
            <div class="item-menu"><a href="kanal.php">Event</a></div>
            <div class="item-menu"><a href="kanal.php">Kolom</a></div>
            <div class="item-menu"><a href="kanal.php">Fokus</a></div>
            <div class="item-menu"><a href="kanal.php">Newsletter</a></div>
            <div class="item-menu"><a href="indeks.php">Indeks</a></div>
        </div>
    </nav>
</div>