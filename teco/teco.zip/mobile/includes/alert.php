<div class="box-alert">
	<div class="alert-in">
    	<button class="alert-cls"><i class="fa fa-times"></i></button>
    	<p>maaf email atau password anda salah</p>
    </div>
</div>